//
//  TaskView.swift
//  Cass_Task2
//
//  Created by Taibah Valley Academy on 3/10/25.
//

import SwiftUI

struct TaskView: View {
  
    @State private var isDarkMode = false  // State variable to track dark mode
    @State private var tasks: [TaskModel] = []  // Array to store tasks
    @State private var newTask = ""  // State variable for user input in the text field
    
    var body: some View {
        NavigationView {
            VStack {
                
                // Toggle button for dark mode
                Toggle("Enable Dark Mode", isOn: $isDarkMode)
                    .padding()
                
                // Title for the task input section
                Text("Add a New Task").font(.headline.bold())
                
                // Task Input Section
                HStack {
                    TextField("Enter task", text: $newTask)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.horizontal)
                  
                    // Add task button
                    Button(action: addTask) {
                        Image(systemName: "plus")
                            .padding()
                            .background(Color.pink)
                            .foregroundColor(.white)
                            .clipShape(Circle())
                            .shadow(radius: 4, x: 0, y: 4)
                    }
                    .padding(.trailing)
                }
                .padding(.vertical)
                .background(Color.gray.opacity(0.2))
                .cornerRadius(10)
               
                // List of tasks
                List {
                    ForEach(tasks) { task in
                        HStack {
                            // Checkbox button to toggle task completion
                            Button(action: { toggleTaskCompletion(task) }) {
                                Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                                    .foregroundColor(task.isCompleted ? .green : .gray)
                            }
                            .buttonStyle(PlainButtonStyle()) // Remove default button style
                                           
                            // Display task title with different styles if completed
                            Text(task.title)
                                .foregroundColor(task.isCompleted ? .gray : .primary)
                        }
                    }
                    .onDelete(perform: deleteTask) // Enable swipe to delete tasks
                }
                .navigationTitle("Tasks Manager")
            }
            .padding()
            .scrollContentBackground(.hidden)
            .preferredColorScheme(isDarkMode ? .dark : .light)  // Apply dark mode setting
        }
    }
    
    // Function to add a new task to the list
    func addTask() {
        if !newTask.isEmpty {
            tasks.append(TaskModel(title: newTask))  // Append the new task
            newTask = ""  // Clear text field
        }
    }
    
    // Function to delete a task from the list
    func deleteTask(at offsets: IndexSet) {
        tasks.remove(atOffsets: offsets)
    }
    
    // Function to toggle the completion status of a task
    func toggleTaskCompletion(_ task: TaskModel) {
        if let index = tasks.firstIndex(where: { $0.id == task.id }) {
            tasks[index].isCompleted.toggle()  // Toggle completed state
        }
    }
}


#Preview {
    TaskView()
}
