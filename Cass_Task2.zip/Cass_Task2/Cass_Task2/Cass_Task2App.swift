//
//  Cass_Task2App.swift
//  Cass_Task2
//
//  Created by Taibah Valley Academy on 3/10/25.
//

import SwiftUI

@main
struct Cass_Task2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
